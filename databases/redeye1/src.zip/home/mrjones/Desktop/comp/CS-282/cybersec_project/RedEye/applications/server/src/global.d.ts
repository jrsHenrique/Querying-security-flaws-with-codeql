declare namespace NodeJS {
	export interface Process {
		pkg: string;
	}
}
